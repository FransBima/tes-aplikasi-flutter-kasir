import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// Data makanan
class FoodItem {
  final String name;
  final String image;
  final double price;

  FoodItem({required this.name, required this.image, required this.price});
}

// Dummy data makanan
final List<FoodItem> foodList = [
  FoodItem(name: "Nasi Goreng", image: "assets/nasi_goreng.jpg", price: 10000),
  FoodItem(name: "Mie Goreng", image: "assets/mie_goreng.jpg", price: 12000),
  FoodItem(name: "Es Teh", image: "assets/esteh.jpg", price: 3000),
  FoodItem(name: "Es Jeruk", image: "assets/esjeruk.jpg", price: 4000),
];

// Keranjang belanja
Map<FoodItem, int> cart = {};

// Halaman Utama
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange[50],
      appBar: AppBar(
        title: const Text("Kuliner Nusantara"),
        centerTitle: true,
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const CartPage()),
                  );
                },
              ),
              if (cart.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.red,
                    child: Text(
                      "${cart.values.fold(0, (sum, count) => sum + count)}",
                      style: const TextStyle(fontSize: 12, color: Colors.white),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset("assets/logo.png", width: 150),
            const SizedBox(height: 20),
            const Text(
              "Selamat Datang di Kuliner Nusantara!",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const MenuPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                textStyle: const TextStyle(fontSize: 18),
              ),
              child: const Text("Lihat Menu"),
            ),
          ],
        ),
      ),
    );
  }
}

// Halaman Menu
class MenuPage extends StatelessWidget {
  const MenuPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Daftar Menu"),
        centerTitle: true,
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const CartPage()),
                  );
                },
              ),
              if (cart.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: CircleAvatar(
                    radius: 10,
                    backgroundColor: Colors.red,
                    child: Text(
                      "${cart.values.fold(0, (sum, count) => sum + count)}",
                      style: const TextStyle(fontSize: 12, color: Colors.white),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(10),
        itemCount: foodList.length,
        itemBuilder: (context, index) {
          return buildFoodItem(context, foodList[index]);
        },
      ),
    );
  }

  Widget buildFoodItem(BuildContext context, FoodItem food) {
    return GestureDetector(
      onTap: () {
        addToCart(food, context);
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              offset: const Offset(1, 2),
              blurRadius: 6,
            ),
          ],
        ),
        height: 120,
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.asset(food.image, width: 100, height: 100, fit: BoxFit.cover),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(food.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  Text("Rp ${food.price}", style: const TextStyle(fontSize: 16, color: Colors.green)),
                ],
              ),
            ),
            IconButton(
              icon: const Icon(Icons.add_shopping_cart),
              onPressed: () {
                addToCart(food, context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void addToCart(FoodItem food, BuildContext context) {
    if (cart.containsKey(food)) {
      cart[food] = cart[food]! + 1;
    } else {
      cart[food] = 1;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("${food.name} ditambahkan ke keranjang")),
    );
  }
}

// Halaman Keranjang
class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  @override
  Widget build(BuildContext context) {
    double totalPrice = cart.entries.fold(0, (sum, entry) => sum + (entry.key.price * entry.value));

    return Scaffold(
      appBar: AppBar(title: const Text("Keranjang")),
      body: cart.isEmpty
          ? const Center(child: Text("Keranjang kosong"))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cart.length,
                    itemBuilder: (context, index) {
                      var entry = cart.entries.elementAt(index);
                      return buildCartItem(entry.key, entry.value);
                    },
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Text("Total: Rp $totalPrice", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            cart.clear();
                          });
                          Navigator.pop(context);
                        },
                        child: const Text("Bayar Sekarang"),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  Widget buildCartItem(FoodItem food, int count) {
    return ListTile(
      title: Text(food.name),
      subtitle: Text("Rp ${food.price} x $count"),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(icon: const Icon(Icons.remove), onPressed: () => setState(() => cart[food] = (cart[food]! - 1).clamp(0, 100))),
          Text("$count"),
          IconButton(icon: const Icon(Icons.add), onPressed: () => setState(() => cart[food] = cart[food]! + 1)),
        ],
      ),
    );
  }
}
